const { users, addUser, getUserByUsername } = require('../models/userModel');

// Handle user registration
const registerUser = (req, res) => {
    const { username, password, email } = req.body;

    // Check if the user already exists
    const existingUser = getUserByUsername(username);
    if (existingUser) {
        return res.status(400).json({ message: 'User already exists' });
    }

    // Create a new user
    const newUser = {
        id: users.length + 1,
        username,
        password,
        email
    };

    addUser(newUser);  // Add new user to the array
    res.status(201).json({ message: 'User registered successfully' });
};

// Handle user login
const loginUser = (req, res) => {
    const { username, password } = req.body;

    // Find user by username
    const user = getUserByUsername(username);

    if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = `Bearer ${user.id}`;  // Token based on user ID
    res.status(200).json({ message: 'Login successful', token });
};

// Handle getting user profile (protected route)
const getProfile = (req, res) => {
    const user = req.user;  // Get the authenticated user from middleware

    res.status(200).json({
        id: user.id,
        username: user.username,
        email: user.email
    });
};

module.exports = {
    registerUser,
    loginUser,
    getProfile
};
