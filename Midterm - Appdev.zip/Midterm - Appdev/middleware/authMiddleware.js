const { getUserById } = require('../models/userModel');

// Authorization middleware
const authMiddleware = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({ message: 'Authorization token missing' });
    }

    const token = authHeader.split(' ')[1];  // Extract the token (user ID)
    const userId = parseInt(token);  // Convert token to an integer

    if (isNaN(userId)) {
        return res.status(401).json({ message: 'Invalid token format' });
    }

    const user = getUserById(userId);  // Find user by token (ID)
    if (!user) {
        return res.status(401).json({ message: 'User not found' });
    }

    req.user = user;  // Attach user to request object
    next();  // Pass control to the next middleware/route
};

module.exports = authMiddleware;
