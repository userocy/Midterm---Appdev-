const express = require('express');
const { registerUser, loginUser, getProfile } = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();  // Router instance

// Registration route
router.post('/register', registerUser);

// Login route
router.post('/login', loginUser);

// Profile route (protected by authMiddleware)
router.get('/profile', authMiddleware, getProfile);

module.exports = router;
